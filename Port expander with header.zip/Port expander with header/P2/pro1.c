#include <REG51F.H>
#include <intrins.h>

sbit sda=P1^7;
sbit scl=P1^6;
void start(void);
void stop(void);
void shout(unsigned char ch);
void shin();
void ack();
void nak();
void error();
void delay(unsigned int);
void wr();
void rd();
unsigned char a,r,p,o,rec_data,flag;

void main()
{
while(1)
{
r=0x01;
for(o=0;o<8;o++)
{
wr();
rd();
P0=rec_data;
delay(1000);
r=r<<1;
}

r=0x80;
for(p=0;p<8;p++)
{
wr();
rd();
P0=rec_data;
delay(1000);
r=r>>1;
}
}
}

void start()
{
sda=1;
scl=1;
_nop_();
_nop_();
_nop_();
sda=0;
_nop_();
_nop_();
_nop_();
scl=0;
}

void stop()
{
sda=0;
scl=1;
_nop_();
_nop_();
_nop_();
sda=1;
_nop_();
_nop_();
_nop_();
scl=0;
}
void shout(unsigned char ch)
{
unsigned char i,j=0x80, temp;
scl=0;
for(i=0;i<8;i++)
{
temp=(ch&j);
if(temp==0)
{
sda=0;
}
else
{
sda=1;
}
scl=1;
_nop_();
_nop_();
_nop_();
scl=0;
j=j>>1;
}
sda=1;
_nop_();
scl=1;
_nop_();
_nop_();
flag=sda;
_nop_();
_nop_();
scl=0;
}

void shin()
{
unsigned char i,j=0x80, k=0;
sda=1;
for(i=0;i<8;i++)
{
scl=1;
_nop_();
_nop_();
_nop_();
if(sda)
k=(j|k);
j=j>>1;
_nop_();
_nop_();
scl=0;
_nop_();
_nop_();
_nop_();
rec_data=k;
}
}
void nack()
{
sda=1;
scl=1;
_nop_();
_nop_();
_nop_();
scl=0;
}

void wr()
{
start();
shout(0x40);
if(CY)
error();
shout(r);
if(CY)
error();
stop();
}

void rd()
{
start();
shout(0x41);
if(CY)
error();
shin();
nack();
stop();
}

void error()
{
P0=0x55;
}
void delay(unsigned int s)
{
unsigned int i,j;
for(i=0;i<s;i++)
{
for(j=0;j<120;j++);
}
}