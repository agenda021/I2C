			void shout(unsigned char dataa)
 {
 unsigned char count, temp;
 scl=0;
 for(count=0;count<8;count++)
 {
 temp=dataa&0x80; //1st bit
 if(temp==0x80) // if bit 1 sda=1 if bit 0 sda=0
 sda=1;
 else
 sda=0;
 
dataa=dataa<<1; //shift bit 1 place
scl=1;
_nop_();
_nop_();
_nop_();
scl=0;		//clock 0 to write next data
}

sda=1;
scl=1;
_nop_();
_nop_();
_nop_(); // master ack part
tb=sda;	 //tb is flag used to get status of sda.
_nop_();
_nop_();
_nop_();
scl=0;
}