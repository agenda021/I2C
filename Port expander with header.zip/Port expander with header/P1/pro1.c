#include <REG51F.H>
#include <intrins.h>

sbit scl=P1^6;
sbit sda=P1^7;
bit tb;

void start(void);
void stop(void);
void shout(unsigned char);
unsigned char shin();
void ack(void);
void nak(void);
void write_pe(unsigned char);
void delay(unsigned int);

code unsigned char rotate[]={0x1,0x2,0x4,0x8,0x10,0x20,0x40,0x80};

void main()
{
unsigned char var, count;
P0=0x00;
while(1)
{
for(count=0;count<8;count++)
{
var=rotate[count];
write_pe(var);
delay(1000);
P0=var;
delay(1000);
}
}
}
#include<write_pe.h>
  #include<mystart.h>
   #include<mystop.h>

 
#include<shout.h>
 
#include<delay.h>

 
