						  
void write_pe(unsigned char z)
{
start();
shout(0x40);//device address sent
if(tb==0)//sda=1 i.e ack with master(uc)
{
shout(z); //data write
if(tb==0)
stop();
}
}