							 
 void delay(unsigned int a)
{
int i,j;
for(i=0;i<a;i++)
for(j=0;j<120;j++);
}
