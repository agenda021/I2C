		  void stop()
 {
 sda=0;
 scl=1;
 _nop_();
 _nop_();
 _nop_();
 sda=1;
 _nop_();
 _nop_();
 _nop_();
 scl=0;
 }