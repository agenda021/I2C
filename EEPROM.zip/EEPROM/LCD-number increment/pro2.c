#include <REG51F.H>
#include <intrins.h>
sbit sda=P1^7;
sbit scl=P1^6;
sbit backlight=P0^0;
sbit rs=P0^1;
sbit rw=P0^2;
sbit en=P0^3;
void start();
void stop();
void sh_out(unsigned char);
unsigned char sh_in();
void rd();
void wr();
void nak();
void ack();
void nop_d();
void init_lcd();
void delay(unsigned int t);
void lcd_cw(unsigned char);
void lcd_dw(unsigned char);
void enable();
unsigned char val1, val2;
unsigned char look_up[10]={"7798346885"};
//=========================================================//

void main()
{
	P0=0x00;
	init_lcd();
	while(1)
	{
		wr();
		delay(1000);
		rd();
	}
}

//=========================================================//

void wr()
{
	start();
	sh_out(0xa0);
	sh_out(0x00);
	sh_out(0x0F);
	sh_out(0x05);
	stop();
}

//=========================================================//

void rd()
{
	unsigned int i;
	start();
	sh_out(0xa0);
	sh_out(0x00);
	sh_out(0x0F);
	start();
	sh_out(0xa1);
	val1=sh_in();
	nak();
	stop();
	lcd_cw(0x85);
	if(i<9)
		i++;
	else
		i=0;
	lcd_dw(look_up[i]);
}

//=========================================================//

void start()
{
	sda=1;
	scl=1;
	nop_d();
	sda=0;
	nop_d();
	scl=0;
}

//=========================================================//

void stop()
{
	sda=0;
	scl=1;
	nop_d();
	sda=1;
	nop_d();
	scl=0;
}

//=========================================================//

void sh_out(unsigned char ch)
{
	unsigned int i, temp;
	sda=0;
	for(i=0;i<8;i++)
	{
		temp=(ch & 0x80);
		if(temp==0x80)
			sda=1;
		else
			sda=0;
		ch=ch<<1;
		scl=1;
		nop_d();
		scl=0;
		nop_d();
	}
	nak();
}

//=========================================================//

unsigned char sh_in()
{
	unsigned char j, kl;
	unsigned int i;
	j=0x80;
	kl=0x00;
	sda=1;
	for(i=0;i<8;i++)
	{
		scl=1;
		nop_d();
		if(sda)
		{
			kl=j|kl;
		}
		j=j>>1;
		nop_d();
		scl=0;
		nop_d();
	}
	return(kl);
}

//=========================================================//

void delay( unsigned int t)
{
	unsigned int i,j;
	for(i=0;i<t;i++)
		for(j=0;j<120;j++);
}

//=========================================================//

void nak()
{	    
	sda=1;
	scl=1;
	nop_d();
	scl=0;
	nop_d();
}

//=========================================================//

void nop_d()
{
_nop_();
_nop_();
_nop_();
_nop_();
_nop_();
}

//=========================================================//

void init_lcd()
{
	delay(15);
	lcd_cw(0x03);
	delay(5);
	lcd_cw(0x03);
	delay(5);
	lcd_cw(0x03);
	delay(5);
	lcd_cw(0x02);
	delay(5);
	lcd_cw(0x10);
	delay(5);
	lcd_cw(0x10);
	delay(5);
	lcd_cw(0x0C);
	delay(5);
	lcd_cw(0x06);
	delay(5);
	lcd_cw(0x01);
	delay(5);
	backlight=0;
}
//=========================================================//

void lcd_cw(unsigned char p)
{
	rs=0;
	rw=0;
	P0=((P0 & 0x0f)|(p & 0xf0));
		enable();
	P0=((P0 & 0x0f)|((p<<4)& 0xf0));
		enable();
}


//=========================================================//

void lcd_dw(unsigned char q)
{
	rs=1;
	rw=0;
	P0=((P0 & 0x0f)|(q & 0xf0));
		enable();
	P0=((P0 & 0x0f)|((q<<4) & 0xf0));
		enable();
}

//=========================================================//

void enable()
{
en=1;
_nop_();
_nop_();
_nop_();
_nop_();
en=0;
_nop_();
_nop_();
}


//=========================================================//
//=========================================================//
//=========================================================//
//=========================================================//
//=========================================================//
//=========================================================//
//=========================================================//
//=========================================================//
//=========================================================//
















