#include <REG51F.H>
#include <intrins.h>

sbit scl=P1^6;
sbit sda=P1^7;
bit tb;

void start(void);
void stop(void);
void shout(unsigned char);
unsigned char shin();
void ack(void);
void nak(void);
void write_pe(unsigned char);
void delay(unsigned int);

code unsigned char rotate[]={0x1,0x2,0x4,0x8,0x10,0x20,0x40,0x80};

void main()
{
unsigned char var, count;
P0=0x00;
while(1)
{
for(count=0;count<8;count++)
{
var=rotate[count];
write_pe(var);
delay(1000);
P0=var;
delay(1000);
}
}
}
void write_pe(unsigned char z)
{
start();
shout(0x40);//device address sent
if(tb==0)//sda=1 i.e ack with master(uc)
{
shout(z); //data write
if(tb==0)
stop();
}
}

void start()
{
sda=1;
scl=1;
if(sda==1)
{
if(scl==1)
{
_nop_();
_nop_();
_nop_();
sda=0;
_nop_();
_nop_();
_nop_();
scl=0;
}
}
}

 void stop()
 {
 sda=0;
 scl=1;
 _nop_();
 _nop_();
 _nop_();
 sda=1;
 _nop_();
 _nop_();
 _nop_();
 scl=0;
 }

/* void ack()
 {
 sda=0;
 scl=1;
 _nop_();
 _nop_();
 _nop_();
 scl=0;
 }

 void nak()
 {
 sda=1;
 scl=1;
 _nop_();
 _nop_();
 _nop_();
 scl=0;
 } */

 void shout(unsigned char dataa)
 {
 unsigned char count, temp;
 scl=0;
 for(count=0;count<8;count++)
 {
 temp=dataa&0x80; //1st bit
 if(temp==0x80) // if bit 1 sda=1 if bit 0 sda=0
 sda=1;
 else
 sda=0;
 
dataa=dataa<<1; //shift bit 1 place
scl=1;
_nop_();
_nop_();
_nop_();
scl=0;		//clock 0 to write next data
}

sda=1;
scl=1;
_nop_();
_nop_();
_nop_(); // master ack part
tb=sda;	 //tb is flag used to get status of sda.
_nop_();
_nop_();
_nop_();
scl=0;
}
 
 /*unsigned char shin()
 {
 unsigned char count, value=0;
 sda=1;
 scl=0;
	  for(count=0;count<8;count++)
	  {
	   _nop_();
	   _nop_();
	   _nop_();
	   scl=1;
	   _nop_();
	   _nop_();
	   tb=sda;
	   if(tb==1)//if sda=0; write sda=0 in value's  d7 bit
	   value=value|0x01;
	   else 
	   value=value|0x00;
	   _nop_();
	   _nop_();
	   _nop_();
	   scl=0;
	   if(count<=6)
	   value=value<<1;
	   }
	   return(value);
	   }
   */
 void delay(unsigned int a)
{
int i,j;
for(i=0;i<a;i++)
for(j=0;j<120;j++);
}


 
