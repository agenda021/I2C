#include <REG51F.H>
#include <intrins.h>
sbit sda=P1^7;
sbit scl=P1^6;
void start();
void sh_out(unsigned char);
void delay(unsigned int t);
void nop_d();
void stop();
void nak();
void pe_write(unsigned char r);
void pe_read();
unsigned char sh_in();
unsigned char data_disp;
unsigned char r;
void main()
{
unsigned int m;
P0=0x00;
r =0x80;
for(m=0;m<8;m++)
{
pe_write(r);
delay(500);
pe_read();
delay(500);
r=r>>1;
}
}

void pe_write(unsigned char r)
{
start();
sh_out(0x40);
sh_out(r);
stop();
}

void pe_read()
{
start();
sh_out(0x41);
P0=sh_in();
nak();
stop();
}

unsigned char sh_in()
{
unsigned char j,kl;
unsigned int i;
j=0x80;
kl=0x00;
sda=1;
for(i=0;i<8;i++)
{
scl=1;
nop_d();
if(sda)
{
kl=j|kl;
}
j=j>>1;
nop_d();
scl=0;
nop_d();
}
return(kl);
}

void start()
{
sda=1;
scl=1;
nop_d();
sda=0;
nop_d();
scl=0;
}

void stop()
{
sda=0;
scl=1;
nop_d();
sda=1;
nop_d();
scl=0;
}




void sh_out(unsigned char ch)
{
unsigned int i, temp;
sda=0;
for(i=0;i<8;i++)
{
temp=(ch&0x80);
if(temp==0x80)
sda=1;
else
sda=0;
ch=ch<<1;
scl=1;
nop_d();
scl=0;
nop_d();
}
nak();
}

void delay(unsigned int t)
{
unsigned int i,j;
for(i=0;i<t;i++)
for(j=0;j<120;j++);
}

void nak()
{
sda=1;
scl=1;
nop_d();
scl=0;
nop_d();
}

void nop_d()
{
_nop_();
_nop_();
_nop_();
_nop_();
_nop_();
}