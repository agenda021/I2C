#include <REG51F.H>
#include <intrins.h>
unsigned int a1, val;
sbit scl=P1^6;
sbit sda=P1^7;
sbit bl=P0^0;
sbit rs=P0^1;
sbit rw=P0^2;
sbit en=P0^3;
void start();
void stop();
void shout(unsigned char);
unsigned char shin();
void delay(unsigned int t);
void nop_d();
void nak();
void wr();
void rd();
unsigned char adc_d;
void init_lcd();
void delay_1ms(unsigned int t);
void lcd_cw(unsigned char);
void lcd_dw(unsigned char);
void enable();  

//---------------------------------------------------//

void main()
{
       P0=0x00;
	   init_lcd();
	   wr();

	   while(1)
	   {
	         rd();
			 delay(100);
	   }
}

//------------------------------------------------------------//

void wr()
{
			start();
			shout(0x90);
			shout(0x00);
			stop();
}

//-----------------------------------------------//

void rd()
{
	start();
	shout(0x91);
	adc_d=shin();
	nak();
	stop();
	lcd_cw(0xc5);
    if(adc_d>=0x00 && adc_d<=0x0f)
    lcd_dw('0');
    else if(adc_d>=0x10 && adc_d<=0x1f)
	lcd_dw('1');
	else if(adc_d>=0x20 && adc_d<=0x2f)
	lcd_dw('2');
	else if(adc_d>=0x30 && adc_d<=0x3f)
	lcd_dw('3');
	else if(adc_d>=0x40 && adc_d<=0x4f)
	lcd_dw('4');
	else if(adc_d>=0x50 && adc_d<=0x5f)
	lcd_dw('5');
	else if(adc_d>=0x60 && adc_d<=0x6f)
	lcd_dw('6');
	else if(adc_d>=0x70 && adc_d<=0x7f)
	lcd_dw('7');
	else if(adc_d>=0x80 && adc_d<=0x8f)
	lcd_dw('8');
	else if(adc_d>=0x90 && adc_d<=0x9f)
	lcd_dw('9');
	else if(adc_d>=0xa0 && adc_d<=0xaf)
	lcd_dw('a');
	else if(adc_d>=0xb0 && adc_d<=0xbf)
	lcd_dw('b');
	else if(adc_d>=0xc0 && adc_d<=0xcf)
	lcd_dw('c');
	else if(adc_d>=0xd0 && adc_d<=0xdf)
	lcd_dw('d');
	else if(adc_d>=0xe0 && adc_d<=0xef)
	lcd_dw('e');
	else if(adc_d>=0xf0 && adc_d<=0xff)
	lcd_dw('f');
}

//----------------------------------//

void start()
{
    sda=1;
	scl=1;
	nop_d();
	sda=0;
	nop_d();
	scl=0;
}
//-----------------------------------//

void stop()
{
    sda=0;
	scl=1;
	nop_d();
	sda=1;
	nop_d();
	scl=0;
}
//------------------------------------//

void shout(unsigned char ch)
{
			unsigned int i, temp;
			sda=0;
			for(i=0;i<8;i++)
			{
						temp =(ch&0x80);
						if(temp==0x80)
						    sda=1;
						else
						    sda=0;  
							ch=ch<<1;
							scl=1;
							nop_d();
							scl=0;
							nop_d();
			}
			nak();
}

//---------------------------------------------//
unsigned char shin()
{
			unsigned char j,kl;
			unsigned int i;
			j=0x80;
			kl=0x00;
			sda=1;
			for(i=0;i<8;i++)
			{
			         scl=1;
					 nop_d();
					 if(sda)
					 {
					         kl=j|kl;
					 }
					 j=j>>1;
					 nop_d();
					 scl=0;
					 nop_d();
			}
			return(kl);
}

//--------------------------------------------//

void nak()
{
      sda=1;
	  scl=1;
	  nop_d();
      scl=0;
	  nop_d();
}
	  
//--------------------------------------------//

void nop_d()
{
       _nop_();
       _nop_();
       _nop_();
       _nop_();
       _nop_();
}



//---------------------------------//
void init_lcd()
{
       delay(15);
       lcd_cw(0x03);
       delay(5);
       lcd_cw(0x03);
       delay(5);
       lcd_cw(0x03);
       delay(5);

       lcd_cw(0x02);
       delay(5);

       lcd_cw(0x28);
       delay(5);
       lcd_cw(0x10);
       delay(5);
       lcd_cw(0x0C);
       delay(5);
       lcd_cw(0x06);
       delay(5);
       lcd_cw(0x01);
       delay(5);
       bl=0;
}

//----------------------------------------------//

void lcd_cw(unsigned char p)
{
       rs=0;
	   rw=0;
	 P0=((P0&0x0f)|(p&0xf0));
	   enable();
	 P0=((P0&0x0f)|((p<<4)&0xf0));
	   enable();
}

//---------------------------------------------//

void lcd_dw(unsigned char q)
{
        rs=1;
		rw=0;
		
	P0=((P0&0x0f)|(q&0xf0));
	  enable();
	P0=((P0&0x0f)|((q<<4)&0xf0));
	  enable();
}

//----------------------------------------------//

void enable()
{       
       en=1;
	   _nop_();
	   _nop_();
	   _nop_(); 
	   _nop_();
	   en=0;
	   _nop_();
	   _nop_();
}
             			   
//---------------------------------------------//
void delay(unsigned int t)
{
      unsigned int i,j;
	  for(i=0;i<=t;i++)
	      for(j=0;j<=120;j++);
}

			       