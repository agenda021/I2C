#include <REG51F.H>
#include <intrins.h>
unsigned a, val;
sbit scl=P1^6;
sbit sda=P1^7;
sbit sl1=P2^0;
sbit sl2=P2^1;
sbit sl3=P2^2;
sbit sl4=P2^3;

bit tb;

void start(void);
void stop(void);
void shout();
void shin();
void delay(unsigned int);
void ack(void);
void nak(void);
void rd();
void wr();
void error();


unsigned char message;
 
 void main()
 {
 P0=0x00;
 wr();

 while(1)
 {
   sl1=0;
   sl2=1;
   sl3=1;
   sl4=1;
   rd();
 
 }
 }

void wr()
{
start();
a=0x90;
shout();
if(CY)
error(); 
a=0x00;
shout();
if(CY)
error();
stop();
}

void rd()
{
start();
a=0x91;
shout();
if(CY)
error();
shin();
nak();
stop();
	if(val>=0x00 && val<=0x0F)
		P0=0xFC;
	else if(val>=0x10 && val<=0x1F)
		P0=0x60;
	else if(val>=0x20 && val<=0x2F)
		P0=0xDA;
	else if(val>=0x30 && val<=0x3F)
		P0=0xF2;
	else if(val>=0x40 && val<=0x4F)
		P0=0x66;
	else if(val>=0x50 && val<=0x5F)
		P0=0xB6;
	else if(val>=0x60 && val<=0x6F)
		P0=0xBE;
	else if(val>=0x70 && val<=0x7F)
		P0=0xE0;
	else if(val>=0x80 && val<=0x8F)
		P0=0xFE;
	else if(val>=0x90 && val<=0x9F)
		P0=0xE6;
	else if(val>=0xA0 && val<=0xAF)
		P0=0xEE;
	else if(val>=0xB0 && val<=0xBF)
		P0=0x3E;
	else if(val>=0xC0 && val<=0xCF)
		P0=0x9C;
	else if(val>=0xD0 && val<=0xDF)
		P0=0x7A;
	else if(val>=0xE0 && val<=0xEF)
		P0=0x9E;
	else if(val>=0xF0 && val<=0xFF)
		P0=0x8E;
		}



void start()
{
sda=1;
scl=1;
_nop_();
_nop_();
_nop_();
sda=0;
_nop_();
_nop_();
_nop_();
scl=0;
}

void stop()
{
sda=0;
scl=1;
_nop_();
_nop_();
_nop_();
sda=1;
_nop_();
_nop_();
_nop_();
scl=0;
}
void ack()
{
sda=0;
scl=1;
_nop_();
_nop_();
_nop_();
scl=0;
} 

void nak()
{
sda=1;
scl=1;
_nop_();
_nop_();
_nop_();
scl=0;
}

void shout()
{
	unsigned int i,temp;
	sda=0;
	for (i=0;i<8;i++)
	{
		temp=a & 0x80;
		if (temp==0x80)
			sda=1;

		else
			sda=0;
		a=a<<1;
		scl=1;
		_nop_();
		_nop_();
		_nop_();
		scl=0;
	}
	 ack();
}



void shin()
{
	unsigned char i,j=0x80,k1=0;
	sda=1;
	for (i=0;i<8;i++)
	{
		scl=1;
		_nop_();
		_nop_();
		_nop_();
		if(sda)
			k1=j|k1;
		j=j>>1;
		_nop_();
		_nop_();
		scl=0;
		_nop_();
		_nop_();
		_nop_();
		val=k1;
	}

}

/*void delay(unsigned int a)
{
int i,j;
for(i=0;i<a;i++)
for(j=0;j<120;j++);
} */

void error()
{
P0=0x55;
}	   
