#include <REG51F.H>
#include <intrins.h>

sbit scl=P1^6;
sbit sda=P1^7;
bit tb;

void start(void);
void stop(void);
void shout(unsigned char);
unsigned char shin();
void delay(unsigned int);
//void ack(void);
void nak(void);
void read_adc(void);
unsigned char message;
 
 void main()12:37 AM 7/5/2013
 {
 P0=0x00;
 while(1)
 {
 read_adc();
 P0=message;
 }
 }

 void read_adc()
 {
 start();
 shout(0x90); //device addr
 if(tb==0)
 {
 shout(0x00);//contol byte
if(tb==0)
{
start();	 //restart
shout(0x91); //read adc
if (tb==0)
{
message=shin();  //receive
nak();
}
}
}
stop();
}

void start()
{
sda=1;
scl=1;
_nop_();
_nop_();
_nop_();
sda=0;
_nop_();
_nop_();
_nop_();
scl=0;
}

void stop()
{
sda=0;
scl=1;
_nop_();
_nop_();
_nop_();
sda=1;
_nop_();
_nop_();
_nop_();
scl=0;
}

/*void ack()
{
sda=0;
scl=1;
_nop_();
_nop_();
_nop_();
scl=0;
} */

void nak()
{
sda=1;
scl=1;
_nop_();
_nop_();
_nop_();
scl=0;
}

void shout(unsigned char ch)
{
unsigned int i, temp;
sda=0;
for(i=0;i<8;i++)
{
temp=(ch&0x80);
if(temp==0x80)
sda=1;
else
sda=0;
ch=ch<<1;
scl=1;
_nop_();
_nop_();
_nop_();
scl=0;
_nop_();
_nop_();
_nop_();
}
nak();
}

unsigned char shin()
{
unsigned char j,kl;
unsigned int i;
j=0x80;
kl=0x00;
sda=1;
for(i=0;i<8;i++)
{
scl=1;
_nop_();
_nop_();
_nop_();
if(sda)
{
kl=j|kl;
}
j=j>>1;
_nop_();
_nop_();
_nop_();
scl=0;
_nop_();
_nop_();
_nop_();

}
return(kl);
}

/*void delay(unsigned int a)
{
int i,j;
for(i=0;i<a;i++)
for(j=0;j<120;j++);
} */

