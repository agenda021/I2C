#include <REG51F.H>
#include<intrins.h>
sbit sda=P1^7;
sbit scl=P1^6;
void nop_d();
void shout(unsigned char);
unsigned char shin();
void delay(unsigned int t);
void init_uart();
void start();
void stop();
void nak();
void rd();
void wr();
unsigned char adc_d;
void uart_tx(unsigned char ch2);
void uart_clr();

//=====================================================//

void main()
{  
   init_uart();
    wr();
    while(1)
	{
		rd();
		delay(1000);
	}	 
}
//=====================================================//

void wr()
{
    start();
    shout(0x90);
    shout(0x00);
    stop();
}

//=====================================================//

void rd()
{
	start();
	shout(0x91);
	adc_d=shin();
	nak();
	stop();
	uart_clr();
	    if(adc_d>=0x00 && adc_d<=0x0f)
	uart_tx('0');
	else if(adc_d>=0x10 && adc_d<=0x1f)
	uart_tx('1');
	else if(adc_d>=0x20 && adc_d<=0x2f)
	uart_tx('2');
	else if(adc_d>=0x30 && adc_d<=0x3f)
	uart_tx('3');
	else if(adc_d>=0x40 && adc_d<=0x4f)
	uart_tx('4');
	else if(adc_d>=0x50 && adc_d<=0x5f)
	uart_tx('5');
	else if(adc_d>=0x60 && adc_d<=0x6f)
	uart_tx('6');
	else if(adc_d>=0x70 && adc_d<=0x7f)
	uart_tx('7');
	else if(adc_d>=0x80 && adc_d<=0x8f)
	uart_tx('8');
	else if(adc_d>=0x90 && adc_d<=0x9f)
	uart_tx('9');
	else if(adc_d>=0xa0 && adc_d<=0xaf)
	uart_tx('A');
	else if(adc_d>=0xb0 && adc_d<=0xbf)
	uart_tx('B');
	else if(adc_d>=0xc0 && adc_d<=0xcf)
	uart_tx('C');
	else if(adc_d>=0xd0 && adc_d<=0xdf)
	uart_tx('D');
	else if(adc_d>=0xe0 && adc_d<=0xef)
	uart_tx('E');
	else if(adc_d>=0xf0 && adc_d<=0xff)
	uart_tx('F');
}

//=====================================================//

void start()
{
    sda=1;
    scl=1;
    nop_d();
    sda=0;
    nop_d();
    scl=0;
}

//=====================================================//

void stop()
{   
	sda=0;
	scl=1;
	nop_d();
	sda=1;
	nop_d();
	scl=0;
}

//=====================================================//

void shout(unsigned char ch)
{
	unsigned int i, temp;
	sda=0;
	for(i=0;i<8;i++)
	{
		temp=(ch&0x80);
		if(temp==0x80)
		    sda=1;
		else
		    sda=0;
		ch=ch<<1;
		scl=1;
		nop_d();
        scl=0;
	    nop_d();
	}
	nak();
}

//=====================================================//

unsigned char shin()
{
	unsigned char j, kl;
	unsigned int i;
	j=0x80;
	kl=0x00;
	sda=1;
	for(i=0;i<8;i++)
	{
		scl=1;
		nop_d();
		if(sda)
		{
			kl=j|kl;
		}
		j=j>>1;
		nop_d();
		scl=0;
		nop_d();
	}
	return(kl);
}

//=====================================================//

void nop_d()
{
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
}

//=====================================================//

void nak()
{
	sda=1;
	scl=1;
	nop_d();
	scl=0;
	nop_d();
}

//=====================================================//

void init_uart()
{
	SCON=0x52;
	TMOD=0x20;
	TR1=1;
	TH1=0x0FD;
}

//=====================================================//

void uart_clr()					  // (to clear uart)
{
	unsigned char tx_data;
	tx_data=0x0d;
	uart_tx(tx_data);
	tx_data=0x0a;
	uart_tx(tx_data);
}

//=====================================================//

void uart_tx(unsigned char ch2)
{
	while(TI==0);
	SBUF=ch2;
	TI=0;
}

//=====================================================//
void delay(unsigned int t)
{
    unsigned int i, j;
    for(i=0;i<t;i++)
       for(j=0;j<120;j++);

}